package ch.ethz.se.rpnc.exception;

public class EmptyStackEvaluationException extends Exception {
	private static final long serialVersionUID = -1018557026903152150L;
}
