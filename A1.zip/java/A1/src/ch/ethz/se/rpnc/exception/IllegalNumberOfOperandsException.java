package ch.ethz.se.rpnc.exception;

public class IllegalNumberOfOperandsException extends Exception {
	private static final long serialVersionUID = -5030210156723846255L;
}
