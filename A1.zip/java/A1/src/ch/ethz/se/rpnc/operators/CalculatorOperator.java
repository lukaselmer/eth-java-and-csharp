package ch.ethz.se.rpnc.operators;

public interface CalculatorOperator {
	double evaluate(double arg1, double arg2);
}
