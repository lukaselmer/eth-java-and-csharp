using System;

namespace Calculator.Exceptions
{
	public class EmptyStackEvaluationException : Exception
	{
	}

}
