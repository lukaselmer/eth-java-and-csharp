using System;

namespace Calculator.Exceptions
{
	public class IllegalNumberOfOperandsException : Exception
	{
	}

}
